package com.example

import android.content.Context
import android.graphics.Color as AndroidColor
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Bundle
import android.view.Display
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.security.SecurityGuard
import com.example.security.TamperLockScreen
import com.example.ui.screens.MainDashboardScreen
import com.example.ui.theme.OtimizadoV500Theme
import com.example.viewmodel.OptimizerViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: OptimizerViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    // Execute SecurityGuard check immediately before loading any main screen
    val isAuthentic = SecurityGuard.isAppAuthentic(this)

    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(AndroidColor.BLACK),
      navigationBarStyle = SystemBarStyle.dark(AndroidColor.BLACK),
    )

    setContent {
      OtimizadoV500Theme {
        if (!isAuthentic) {
          TamperLockScreen()
        } else {
          val requestRefreshBoost by
            viewModel.requestWindowRefreshBoost.collectAsStateWithLifecycle()
          val requestSustainedPerf by
            viewModel.requestSustainedPerformance.collectAsStateWithLifecycle()

          LaunchedEffect(requestRefreshBoost) {
            if (requestRefreshBoost) applyMaxWindowRefreshRate()
          }
          LaunchedEffect(requestSustainedPerf) {
            runCatching { window.setSustainedPerformanceMode(requestSustainedPerf) }
          }

          MainDashboardScreen(viewModel = viewModel)
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    if (SecurityGuard.isAppAuthentic(this)) {
      viewModel.startMonitoring()
    }
  }

  override fun onPause() {
    super.onPause()
    viewModel.stopMonitoring()
  }

  private fun applyMaxWindowRefreshRate() {
    runCatching {
      val dm = getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
      val display = dm?.getDisplay(Display.DEFAULT_DISPLAY) ?: return@runCatching
      val bestMode = display.supportedModes.maxByOrNull { it.refreshRate } ?: return@runCatching
      val params = window.attributes
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        params.preferredDisplayModeId = bestMode.modeId
      } else {
        params.preferredRefreshRate = bestMode.refreshRate
      }
      window.attributes = params
    }
  }
}
