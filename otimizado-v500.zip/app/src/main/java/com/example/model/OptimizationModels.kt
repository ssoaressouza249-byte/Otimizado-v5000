package com.example.model

import android.content.Context

enum class OptimizationCategory(val tabTitle: String) {
  FPS_AND_HZ("FPS & Hz"),
  TOUCH_DELAY("Zero Delay"),
  LIGHT_SYSTEM("Apps Leves"),
}

enum class ShizukuStatus {
  CONNECTED,
  PERMISSION_REQUIRED,
  NOT_RUNNING,
}

data class InstalledAppInfo(
  val packageName: String,
  val label: String,
  val isFreeFire: Boolean,
)

data class TelemetryState(
  val currentFps: Int = 60,
  val refreshRateHz: Float = 60f,
  val maxSupportedHz: Float = 60f,
  val freeRamMb: Long = 0L,
  val totalRamMb: Long = 0L,
)

data class OptimizationFeature(
  val id: Int,
  val title: String,
  val description: String,
  val commandPreview: String,
  val category: OptimizationCategory,
  val enableCommands: (context: Context, targetPackage: String, maxHz: Float) -> List<String>,
  val disableCommands: (context: Context, targetPackage: String) -> List<String>,
  val nativeFallback: (context: Context, targetPackage: String, enabled: Boolean) -> String,
)
