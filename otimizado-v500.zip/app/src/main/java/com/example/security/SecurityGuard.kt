package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

object SecurityGuard {
  private const val EXPECTED_PACKAGE = "com.raylan.otimizadov500"
  private const val EXPECTED_APP_NAME = "Otimizado V500"

  /**
   * Verifies strictly that packageName and application label were not modified
   * (e.g., by MT Manager, NP Manager, APK Editor). Does NOT block debug certificates.
   */
  fun isAppAuthentic(context: Context): Boolean {
    val pkgOk = runCatching { context.packageName == EXPECTED_PACKAGE }.getOrDefault(false)
    val labelOk =
      runCatching {
          val label = context.applicationInfo.loadLabel(context.packageManager).toString().trim()
          label == EXPECTED_APP_NAME
        }
        .getOrDefault(false)
    return pkgOk && labelOk
  }
}

@Composable
fun TamperLockScreen() {
  val context = LocalContext.current

  // Disable hardware/gesture back navigation permanently while tampered
  BackHandler(enabled = true) {}

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Color(0xFFB71C1C))
        .systemBarsPadding()
        .padding(horizontal = 24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.fillMaxWidth(),
    ) {
      Icon(
        imageVector = Icons.Filled.Security,
        contentDescription = "Alerta de Segurança",
        tint = Color.White,
        modifier = Modifier.size(84.dp),
      )

      Spacer(modifier = Modifier.height(24.dp))

      Text(
        text = stringResource(id = R.string.security_alert_message),
        color = Color.White,
        fontSize = 18.sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = FontFamily.Default,
        textAlign = TextAlign.Center,
        lineHeight = 26.sp,
        modifier = Modifier.testTag("security_alert_text"),
      )

      Spacer(modifier = Modifier.height(36.dp))

      Button(
        onClick = {
          runCatching {
            val intent =
              Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
              }
            context.startActivity(intent)
          }
        },
        colors =
          ButtonDefaults.buttonColors(
            containerColor = Color.White,
            contentColor = Color(0xFFB71C1C),
          ),
        shape = RoundedCornerShape(14.dp),
        modifier =
          Modifier.fillMaxWidth()
            .height(60.dp)
            .testTag("uninstall_tampered_button"),
      ) {
        Text(
          text = stringResource(id = R.string.btn_uninstall_now),
          fontSize = 17.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Default,
          letterSpacing = 0.8.sp,
        )
      }
    }
  }
}
