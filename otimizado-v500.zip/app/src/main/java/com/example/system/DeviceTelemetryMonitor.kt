package com.example.system

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Choreographer
import android.view.Display
import com.example.model.InstalledAppInfo
import com.example.model.TelemetryState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DeviceTelemetryMonitor(private val context: Context) {

  companion object {
    const val FREE_FIRE_PKG = "com.dts.freefireth"
    const val FREE_FIRE_MAX_PKG = "com.dts.freefiremax"
  }

  private val _telemetry = MutableStateFlow(TelemetryState())
  val telemetry: StateFlow<TelemetryState> = _telemetry.asStateFlow()

  private var frameCount = 0
  private var lastWindowNs = 0L
  private var isTrackingFps = false

  private val frameCallback =
    object : Choreographer.FrameCallback {
      override fun doFrame(frameTimeNanos: Long) {
        if (!isTrackingFps) return
        if (lastWindowNs == 0L) {
          lastWindowNs = frameTimeNanos
        }
        frameCount++
        val elapsedNs = frameTimeNanos - lastWindowNs
        if (elapsedNs >= 500_000_000L) {
          val measuredFps = ((frameCount * 1_000_000_000.0) / elapsedNs).toInt().coerceIn(1, 240)
          frameCount = 0
          lastWindowNs = frameTimeNanos
          updateTelemetrySnapshot(measuredFps)
        }
        runCatching { Choreographer.getInstance().postFrameCallback(this) }
      }
    }

  fun start() {
    if (isTrackingFps) return
    isTrackingFps = true
    frameCount = 0
    lastWindowNs = 0L
    updateTelemetrySnapshot(_telemetry.value.currentFps)
    runCatching { Choreographer.getInstance().postFrameCallback(frameCallback) }
  }

  fun stop() {
    isTrackingFps = false
    runCatching { Choreographer.getInstance().removeFrameCallback(frameCallback) }
  }

  fun refreshOnce() {
    updateTelemetrySnapshot(_telemetry.value.currentFps)
  }

  private fun updateTelemetrySnapshot(fps: Int) {
    val (currentHz, maxHz) = readDisplayRates()
    val (freeMb, totalMb) = readMemoryInfo()
    _telemetry.value =
      TelemetryState(
        currentFps = fps,
        refreshRateHz = currentHz,
        maxSupportedHz = maxHz,
        freeRamMb = freeMb,
        totalRamMb = totalMb,
      )
  }

  private fun readDisplayRates(): Pair<Float, Float> {
    return runCatching {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display: Display? = dm?.getDisplay(Display.DEFAULT_DISPLAY)
        if (display != null) {
          val current = display.refreshRate
          val maxMode = display.supportedModes.maxOfOrNull { it.refreshRate } ?: current
          current to maxOf(current, maxMode)
        } else {
          60f to 60f
        }
      }
      .getOrDefault(60f to 60f)
  }

  private fun readMemoryInfo(): Pair<Long, Long> {
    return runCatching {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        if (am != null) {
          am.getMemoryInfo(memInfo)
          val freeMb = memInfo.availMem / (1024L * 1024L)
          val totalMb = memInfo.totalMem / (1024L * 1024L)
          freeMb to totalMb
        } else {
          0L to 0L
        }
      }
      .getOrDefault(0L to 0L)
  }

  fun loadInstalledApps(): List<InstalledAppInfo> {
    return runCatching {
        val pm = context.packageManager
        val apps =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
          } else {
            @Suppress("DEPRECATION") pm.getInstalledApplications(0)
          }

        val selfPackage = context.packageName
        val launchableApps =
          apps
            .asSequence()
            .filter { info ->
              info.packageName != selfPackage &&
                pm.getLaunchIntentForPackage(info.packageName) != null
            }
            .map { info ->
              val label =
                runCatching { pm.getApplicationLabel(info).toString().trim() }
                  .getOrDefault(info.packageName)
              val isFreeFire =
                info.packageName == FREE_FIRE_PKG || info.packageName == FREE_FIRE_MAX_PKG
              val isUserApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) == 0
              Triple(InstalledAppInfo(info.packageName, label, isFreeFire), isFreeFire, isUserApp)
            }
            .sortedWith(
              compareByDescending<Triple<InstalledAppInfo, Boolean, Boolean>> { it.second }
                .thenByDescending { it.third }
                .thenBy { it.first.label.lowercase() }
            )
            .map { it.first }
            .toList()

        if (launchableApps.any { it.isFreeFire }) {
          launchableApps
        } else {
          // Ensure Free Fire entry is always selectable even if not yet installed on emulator/device
          listOf(
            InstalledAppInfo(
              packageName = FREE_FIRE_PKG,
              label = "Free Fire (com.dts.freefireth)",
              isFreeFire = true,
            ),
            InstalledAppInfo(
              packageName = FREE_FIRE_MAX_PKG,
              label = "Free Fire MAX (com.dts.freefiremax)",
              isFreeFire = true,
            ),
          ) + launchableApps
        }
      }
      .getOrElse {
        listOf(
          InstalledAppInfo(
            packageName = FREE_FIRE_PKG,
            label = "Free Fire (com.dts.freefireth)",
            isFreeFire = true,
          )
        )
      }
  }

  fun getNonEssentialThirdPartyPackages(excludePackage: String): List<String> {
    return runCatching {
        val pm = context.packageManager
        val apps =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
          } else {
            @Suppress("DEPRECATION") pm.getInstalledApplications(0)
          }
        val selfPkg = context.packageName
        apps
          .asSequence()
          .filter { info ->
            val isUserApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) == 0
            isUserApp &&
              info.packageName != selfPkg &&
              info.packageName != excludePackage &&
              info.packageName != "moe.shizuku.privileged.api"
          }
          .map { it.packageName }
          .take(20)
          .toList()
      }
      .getOrDefault(emptyList())
  }

  fun clearBackgroundProcessesNative(): Int {
    return runCatching {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0
        val pm = context.packageManager
        val apps =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
          } else {
            @Suppress("DEPRECATION") pm.getInstalledApplications(0)
          }
        var count = 0
        val selfPkg = context.packageName
        for (app in apps) {
          if (app.packageName != selfPkg && (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0) {
            runCatching {
              am.killBackgroundProcesses(app.packageName)
              count++
            }
          }
        }
        count
      }
      .getOrDefault(0)
  }
}
