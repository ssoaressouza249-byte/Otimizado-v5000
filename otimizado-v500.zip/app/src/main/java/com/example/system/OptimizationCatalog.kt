package com.example.system

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.model.OptimizationCategory
import com.example.model.OptimizationFeature

object OptimizationCatalog {

  fun getAllFeatures(): List<OptimizationFeature> =
    listOf(
      // ==================== ABA 1: FPS & Hz EXTREMO (9 FUNÇÕES) ====================
      OptimizationFeature(
        id = 1,
        title = "Desbloquear 120Hz/144Hz Fixo",
        description = "Trava a taxa máxima e mínima do painel em até 144Hz para fluidez extrema.",
        commandPreview = "settings put system peak_refresh_rate 144.0",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, _, maxHz ->
          val targetPeak = maxOf(144f, maxHz)
          val targetMin = if (maxHz >= 120f) 120f else maxHz
          listOf(
            "settings put system peak_refresh_rate $targetPeak",
            "settings put system min_refresh_rate $targetMin",
          )
        },
        disableCommands = { _, _ ->
          listOf(
            "settings put system min_refresh_rate 60.0",
            "settings delete system peak_refresh_rate",
          )
        },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Modo de taxa de atualização máxima solicitado na janela ativa."
          else "Taxa de atualização restaurada para padrão do sistema."
        },
      ),
      OptimizationFeature(
        id = 2,
        title = "Modo Game Performance API",
        description = "Ativa o perfil oficial de desempenho máximo do Game Manager no pacote alvo.",
        commandPreview = "cmd game mode performance <pacote>",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, pkg, _ -> listOf("cmd game mode performance $pkg") },
        disableCommands = { _, pkg -> listOf("cmd game mode standard $pkg") },
        nativeFallback = { _, pkg, enabled ->
          if (enabled) "Game Mode de alta prioridade marcado para $pkg (requer Shizuku para cmd game)."
          else "Game Mode padrão restaurado para $pkg."
        },
      ),
      OptimizationFeature(
        id = 3,
        title = "Forçar Renderização GPU 2D",
        description = "Direciona o pipeline HWUI para SkiaGL acelerado por GPU.",
        commandPreview = "setprop debug.hwui.renderer skiagl",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, _, _ -> listOf("setprop debug.hwui.renderer skiagl") },
        disableCommands = { _, _ -> listOf("setprop debug.hwui.renderer skiavk") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Aceleração de hardware GPU ativa no renderizador local."
          else "Renderizador padrão restaurado."
        },
      ),
      OptimizationFeature(
        id = 4,
        title = "Desativar VSync / Limite de Frames",
        description = "Remove o bloqueio de swapinterval EGL para liberar taxa de quadros.",
        commandPreview = "setprop debug.egl.swapinterval 0",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, _, _ -> listOf("setprop debug.egl.swapinterval 0") },
        disableCommands = { _, _, -> listOf("setprop debug.egl.swapinterval 1") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Ajuste de frame pacing sem trava configurado localmente."
          else "Sincronização VSync padrão restaurada."
        },
      ),
      OptimizationFeature(
        id = 5,
        title = "Prioridade Máxima de GPU (SurfaceFlinger)",
        description = "Eleva prioridade de composição do SurfaceFlinger para evitar engasgos.",
        commandPreview = "service call SurfaceFlinger 1008 i32 1",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, _, _ -> listOf("service call SurfaceFlinger 1008 i32 1") },
        disableCommands = { _, _ -> listOf("service call SurfaceFlinger 1008 i32 0") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Prioridade de thread de renderização elevada no processo."
          else "Prioridade padrão restaurada."
        },
      ),
      OptimizationFeature(
        id = 6,
        title = "Ativar Modo Desempenho Fixo",
        description = "Ativa Sustained Performance / Fixed Performance Mode para clocks estáveis.",
        commandPreview = "cmd power set-fixed-performance-mode-enabled true",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, _, _ ->
          listOf("cmd power set-fixed-performance-mode-enabled true")
        },
        disableCommands = { _, _ ->
          listOf("cmd power set-fixed-performance-mode-enabled false")
        },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Sustained Performance Mode aplicado na Activity atual."
          else "Sustained Performance Mode desativado."
        },
      ),
      OptimizationFeature(
        id = 7,
        title = "Estabilizador de Frame Pacing",
        description = "Ajusta o múltiplo de frame rate do SurfaceFlinger para 120fps consistentes.",
        commandPreview = "setprop debug.sf.frame_rate_multiple_threshold 120",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, _, _ ->
          listOf("setprop debug.sf.frame_rate_multiple_threshold 120")
        },
        disableCommands = { _, _ ->
          listOf("setprop debug.sf.frame_rate_multiple_threshold 60")
        },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Monitor de frame pacing calibrado em 120Hz."
          else "Calibração padrão de frame pacing restaurada."
        },
      ),
      OptimizationFeature(
        id = 8,
        title = "Aceleração de Compositor de Tela",
        description = "Habilita latch_unsignaled no SurfaceFlinger para reduzir latência de exibição.",
        commandPreview = "setprop debug.sf.latch_unsignaled 1",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, _, _ -> listOf("setprop debug.sf.latch_unsignaled 1") },
        disableCommands = { _, _ -> listOf("setprop debug.sf.latch_unsignaled 0") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Compositor otimizado para baixa latência."
          else "Compositor restaurado."
        },
      ),
      OptimizationFeature(
        id = 9,
        title = "Turbo Clock Thermal Bypass",
        description = "Evita queda brusca de clock térmico em partidas longas.",
        commandPreview = "cmd thermalservice override-status 0",
        category = OptimizationCategory.FPS_AND_HZ,
        enableCommands = { _, _, _ -> listOf("cmd thermalservice override-status 0") },
        disableCommands = { _, _ -> listOf("cmd thermalservice reset") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Perfil térmico Turbo registrado (controle completo requer Shizuku)."
          else "Controle térmico restaurado ao padrão."
        },
      ),

      // ==================== ABA 2: ZERO DELAY DE TOQUE (8 FUNÇÕES) ====================
      OptimizationFeature(
        id = 10,
        title = "Resposta de Toque Instantânea",
        description = "Reduz o touch_slop ao mínimo (1px) para registro imediato do primeiro toque.",
        commandPreview = "settings put secure touch_slop 1",
        category = OptimizationCategory.TOUCH_DELAY,
        enableCommands = { _, _, _ -> listOf("settings put secure touch_slop 1") },
        disableCommands = { _, _ -> listOf("settings delete secure touch_slop") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Touch slop reduzido no perfil da sessão."
          else "Touch slop padrão restaurado."
        },
      ),
      OptimizationFeature(
        id = 11,
        title = "Taxa de Amostragem de Toque Máxima",
        description = "Força o driver de touch polling rate para resposta contínua de alta frequência.",
        commandPreview = "settings put system touch_polling_rate 1",
        category = OptimizationCategory.TOUCH_DELAY,
        enableCommands = { _, _, _ -> listOf("settings put system touch_polling_rate 1") },
        disableCommands = { _, _ -> listOf("settings put system touch_polling_rate 0") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Solicitação de amostragem máxima de toque registrada."
          else "Amostragem de toque restaurada."
        },
      ),
      OptimizationFeature(
        id = 12,
        title = "Remover Atraso de Toque Longo",
        description = "Reduz long_press_timeout para 150ms eliminando espera em comandos rápidos.",
        commandPreview = "settings put secure long_press_timeout 150",
        category = OptimizationCategory.TOUCH_DELAY,
        enableCommands = { _, _, _ -> listOf("settings put secure long_press_timeout 150") },
        disableCommands = { _, _ -> listOf("settings put secure long_press_timeout 400") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Tempo de toque longo ajustado para resposta rápida."
          else "Tempo de toque longo restaurado (400ms)."
        },
      ),
      OptimizationFeature(
        id = 13,
        title = "Desativar Gestos de Sistema Conflitantes",
        description = "Zera as bordas de gesto Voltar esquerda/direita para evitar travar a mira.",
        commandPreview = "settings put secure back_gesture_inset_scale_left 0",
        category = OptimizationCategory.TOUCH_DELAY,
        enableCommands = { _, _, _ ->
          listOf(
            "settings put secure back_gesture_inset_scale_left 0",
            "settings put secure back_gesture_inset_scale_right 0",
          )
        },
        disableCommands = { _, _ ->
          listOf(
            "settings put secure back_gesture_inset_scale_left 1",
            "settings put secure back_gesture_inset_scale_right 1",
          )
        },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Proteção contra gestos laterais ativada."
          else "Gestos laterais do sistema restaurados."
        },
      ),
      OptimizationFeature(
        id = 14,
        title = "Aceleração de Sensibilidade X/Y",
        description = "Define pointer_speed no máximo (7) para puxada de capa e movimentação ágil.",
        commandPreview = "settings put system pointer_speed 7",
        category = OptimizationCategory.TOUCH_DELAY,
        enableCommands = { _, _, _ -> listOf("settings put system pointer_speed 7") },
        disableCommands = { _, _ -> listOf("settings put system pointer_speed 0") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Sensibilidade X/Y elevada no perfil ativo."
          else "Sensibilidade padrão restaurada."
        },
      ),
      OptimizationFeature(
        id = 15,
        title = "Remover Delay de Toque Múltiplo",
        description = "Reduz multi_press_timeout para 150ms agilizando toques simultâneos.",
        commandPreview = "settings put secure multi_press_timeout 150",
        category = OptimizationCategory.TOUCH_DELAY,
        enableCommands = { _, _, _ -> listOf("settings put secure multi_press_timeout 150") },
        disableCommands = { _, _ -> listOf("settings put secure multi_press_timeout 300") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Multi-touch boost configurado em 150ms."
          else "Multi-touch timeout restaurado."
        },
      ),
      OptimizationFeature(
        id = 16,
        title = "Desativar Vibração de Toque",
        description = "Desliga haptic_feedback_enabled para eliminar atraso mecânico do motor.",
        commandPreview = "settings put system haptic_feedback_enabled 0",
        category = OptimizationCategory.TOUCH_DELAY,
        enableCommands = { _, _, _ -> listOf("settings put system haptic_feedback_enabled 0") },
        disableCommands = { _, _ -> listOf("settings put system haptic_feedback_enabled 1") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Feedback háptico silenciado no app para zero lag."
          else "Feedback háptico restaurado."
        },
      ),
      OptimizationFeature(
        id = 17,
        title = "Predição de Movimento de Toque",
        description = "Ativa motion prediction no subsistema de toque para rastreio preditivo.",
        commandPreview = "setprop persist.sys.touch.prediction 1",
        category = OptimizationCategory.TOUCH_DELAY,
        enableCommands = { _, _, _ -> listOf("setprop persist.sys.touch.prediction 1") },
        disableCommands = { _, _ -> listOf("setprop persist.sys.touch.prediction 0") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Predição de movimento de toque habilitada."
          else "Predição de toque desativada."
        },
      ),

      // ==================== ABA 3: DEIXAR APPS & SISTEMA LEVES (8 FUNÇÕES) ====================
      OptimizationFeature(
        id = 18,
        title = "Zerar Animações do Sistema",
        description = "Zera window, transition e animator scale para transições instantâneas.",
        commandPreview = "settings put global window_animation_scale 0",
        category = OptimizationCategory.LIGHT_SYSTEM,
        enableCommands = { _, _, _ ->
          listOf(
            "settings put global window_animation_scale 0",
            "settings put global transition_animation_scale 0",
            "settings put global animator_duration_scale 0",
          )
        },
        disableCommands = { _, _ ->
          listOf(
            "settings put global window_animation_scale 1",
            "settings put global transition_animation_scale 1",
            "settings put global animator_duration_scale 1",
          )
        },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Animações reduzidas no app para transição instantânea."
          else "Escalas de animação padrão restauradas."
        },
      ),
      OptimizationFeature(
        id = 19,
        title = "Limpeza Profunda de Cache do Sistema",
        description = "Libera até 1GB de caches temporários acumulados via PackageManager.",
        commandPreview = "pm trim-caches 1024M",
        category = OptimizationCategory.LIGHT_SYSTEM,
        enableCommands = { _, _, _ -> listOf("pm trim-caches 1024M") },
        disableCommands = { _, _ -> emptyList() },
        nativeFallback = { context, _, enabled ->
          if (enabled) {
            runCatching { context.cacheDir?.deleteRecursively() }
            "Cache local limpo; trim global completo requer Shizuku."
          } else {
            "Limpeza de cache desmarcada."
          }
        },
      ),
      OptimizationFeature(
        id = 20,
        title = "Encerrar Processos Ociosos",
        description = "Finaliza processos em segundo plano com am kill-all liberando RAM para o jogo.",
        commandPreview = "am kill-all",
        category = OptimizationCategory.LIGHT_SYSTEM,
        enableCommands = { _, _, _ -> listOf("am kill-all") },
        disableCommands = { _, _ -> emptyList() },
        nativeFallback = { context, _, enabled ->
          if (enabled) {
            val killed = killBackgroundNative(context)
            "Limpeza nativa executada em $killed apps em segundo plano."
          } else {
            "Monitoramento em segundo plano normalizado."
          }
        },
      ),
      OptimizationFeature(
        id = 21,
        title = "Restringir Apps em Segundo Plano (AppOps)",
        description = "Bloqueia execução ociosa de apps não essenciais via cmd appops set.",
        commandPreview = "cmd appops set <apps> RUN_IN_BACKGROUND ignore",
        category = OptimizationCategory.LIGHT_SYSTEM,
        enableCommands = { context, targetPkg, _ ->
          val pkgs = getRestrictablePackages(context, targetPkg)
          if (pkgs.isEmpty()) {
            emptyList()
          } else {
            pkgs.flatMap { pkg ->
              listOf(
                "cmd appops set $pkg RUN_IN_BACKGROUND ignore",
                "cmd appops set $pkg RUN_ANY_IN_BACKGROUND ignore",
              )
            }
          }
        },
        disableCommands = { context, targetPkg ->
          val pkgs = getRestrictablePackages(context, targetPkg)
          pkgs.flatMap { pkg ->
            listOf(
              "cmd appops set $pkg RUN_IN_BACKGROUND allow",
              "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow",
            )
          }
        },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Restrição AppOps preparada (aplicação total via Shizuku)."
          else "Permissões de segundo plano restauradas."
        },
      ),
      OptimizationFeature(
        id = 22,
        title = "Modo Economia de Textura Leve",
        description = "Desativa buffer_age do HWUI para reduzir consumo de VRAM e largura de banda.",
        commandPreview = "setprop debug.hwui.use_buffer_age false",
        category = OptimizationCategory.LIGHT_SYSTEM,
        enableCommands = { _, _, _ -> listOf("setprop debug.hwui.use_buffer_age false") },
        disableCommands = { _, _ -> listOf("setprop debug.hwui.use_buffer_age true") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Perfil de memória gráfica leve ativado."
          else "Perfil gráfico padrão restaurado."
        },
      ),
      OptimizationFeature(
        id = 23,
        title = "Desativar Logs e Telemetria Pesada",
        description = "Silencia stats_log para reduzir escrita em disco e sobrecarga de CPU.",
        commandPreview = "setprop log.tag.stats_log OFF",
        category = OptimizationCategory.LIGHT_SYSTEM,
        enableCommands = { _, _, _ -> listOf("setprop log.tag.stats_log OFF") },
        disableCommands = { _, _ -> listOf("setprop log.tag.stats_log INFO") },
        nativeFallback = { _, _, enabled ->
          if (enabled) "Telemetria reduzida no processo."
          else "Nível de log padrão restaurado."
        },
      ),
      OptimizationFeature(
        id = 24,
        title = "Otimizar Compilação JIT/Speed",
        description = "Recompila o app alvo com perfil speed-profile para abertura e FPS mais rápidos.",
        commandPreview = "cmd package compile -m speed-profile -f <pacote>",
        category = OptimizationCategory.LIGHT_SYSTEM,
        enableCommands = { _, pkg, _ -> listOf("cmd package compile -m speed-profile -f $pkg") },
        disableCommands = { _, _ -> emptyList() },
        nativeFallback = { _, pkg, enabled ->
          if (enabled) "Perfil speed-profile enfileirado para $pkg (requer Shizuku)."
          else "Compilação automática restaurada."
        },
      ),
      OptimizationFeature(
        id = 25,
        title = "Liberar Memória ZRAM & Buffers",
        description = "Executa sync e limpa caches de página/dentries/inodes do kernel.",
        commandPreview = "sync && echo 3 > /proc/sys/vm/drop_caches",
        category = OptimizationCategory.LIGHT_SYSTEM,
        enableCommands = { _, _, _ -> listOf("sync && echo 3 > /proc/sys/vm/drop_caches") },
        disableCommands = { _, _ -> emptyList() },
        nativeFallback = { _, _, enabled ->
          if (enabled) {
            runCatching { System.gc() }
            "GC da VM executado; drop_caches do kernel requer Shizuku/root."
          } else {
            "Gerenciamento de buffers padrão ativo."
          }
        },
      ),
    )

  private fun getRestrictablePackages(context: Context, targetPackage: String): List<String> {
    return runCatching {
        val pm = context.packageManager
        val apps =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
          } else {
            @Suppress("DEPRECATION") pm.getInstalledApplications(0)
          }
        val selfPkg = context.packageName
        apps
          .asSequence()
          .filter { info ->
            val isUserApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) == 0
            isUserApp &&
              info.packageName != selfPkg &&
              info.packageName != targetPackage &&
              info.packageName != "moe.shizuku.privileged.api"
          }
          .map { it.packageName }
          .take(15)
          .toList()
      }
      .getOrDefault(emptyList())
  }

  private fun killBackgroundNative(context: Context): Int {
    return runCatching {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0
        val pm = context.packageManager
        val apps =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
          } else {
            @Suppress("DEPRECATION") pm.getInstalledApplications(0)
          }
        var count = 0
        val selfPkg = context.packageName
        for (app in apps) {
          if (app.packageName != selfPkg && (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0) {
            runCatching {
              am.killBackgroundProcesses(app.packageName)
              count++
            }
          }
        }
        count
      }
      .getOrDefault(0)
  }
}
