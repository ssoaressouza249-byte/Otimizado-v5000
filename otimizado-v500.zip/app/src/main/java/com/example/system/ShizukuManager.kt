package com.example.system

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.example.model.ShizukuStatus
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class ShizukuManager {

  companion object {
    private const val SHIZUKU_REQUEST_CODE = 5001
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
  }

  private val _status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
  val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

  private val binderReceivedListener = Shizuku.OnBinderReceivedListener { refreshStatus() }
  private val binderDeadListener = Shizuku.OnBinderDeadListener { refreshStatus() }
  private val permissionResultListener =
    Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
      if (requestCode == SHIZUKU_REQUEST_CODE) {
        refreshStatus()
      }
    }

  private var listenersRegistered = false

  fun registerListeners() {
    if (listenersRegistered) return
    runCatching {
      Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
      Shizuku.addBinderDeadListener(binderDeadListener)
      Shizuku.addRequestPermissionResultListener(permissionResultListener)
      listenersRegistered = true
    }
    refreshStatus()
  }

  fun unregisterListeners() {
    if (!listenersRegistered) return
    runCatching {
      Shizuku.removeBinderReceivedListener(binderReceivedListener)
      Shizuku.removeBinderDeadListener(binderDeadListener)
      Shizuku.removeRequestPermissionResultListener(permissionResultListener)
      listenersRegistered = false
    }
  }

  fun refreshStatus(): ShizukuStatus {
    val resolved =
      runCatching {
          if (!Shizuku.pingBinder()) {
            ShizukuStatus.NOT_RUNNING
          } else if (Shizuku.isPreV11()) {
            ShizukuStatus.NOT_RUNNING
          } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            ShizukuStatus.CONNECTED
          } else {
            ShizukuStatus.PERMISSION_REQUIRED
          }
        }
        .getOrDefault(ShizukuStatus.NOT_RUNNING)
    _status.value = resolved
    return resolved
  }

  fun requestOrOpenShizuku(context: Context): String {
    val current = refreshStatus()
    return when (current) {
      ShizukuStatus.CONNECTED -> "Shizuku já está conectado e autorizado."
      ShizukuStatus.PERMISSION_REQUIRED -> {
        val requested =
          runCatching {
              if (Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
              } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
              }
              true
            }
            .getOrDefault(false)
        if (requested) "Solicitação de permissão Shizuku enviada."
        else "Falha ao solicitar permissão no Shizuku."
      }
      ShizukuStatus.NOT_RUNNING -> {
        val openedApp =
          runCatching {
              val launchIntent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
              if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
              } else {
                false
              }
            }
            .getOrDefault(false)
        if (openedApp) {
          "Abrindo app Shizuku para ativar o serviço..."
        } else {
          runCatching {
            val marketIntent =
              Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PACKAGE"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(marketIntent)
          }
            .onFailure {
              runCatching {
                val webIntent =
                  Intent(
                      Intent.ACTION_VIEW,
                      Uri.parse("https://play.google.com/store/apps/details?id=$SHIZUKU_PACKAGE"),
                    )
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(webIntent)
              }
            }
          "Shizuku não encontrado. Modo nativo ativo; instale o Shizuku para nível root/ADB."
        }
      }
    }
  }

  suspend fun executeCommand(command: String): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val currentStatus = refreshStatus()
        if (currentStatus == ShizukuStatus.CONNECTED) {
          val process = createShizukuProcess(command)
          try {
            val stdout =
              BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val stderr =
              BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
            process.waitFor(8, TimeUnit.SECONDS)
            val exitCode = runCatching { process.exitValue() }.getOrDefault(0)
            val combined = buildString {
              if (stdout.isNotBlank()) append(stdout.trim())
              if (stderr.isNotBlank()) {
                if (isNotEmpty()) append(" | ")
                append(stderr.trim())
              }
            }
            if (exitCode == 0) {
              combined.ifBlank { "OK (Shizuku)" }
            } else {
              throw IllegalStateException(
                combined.ifBlank { "Exit code $exitCode" }
              )
            }
          } finally {
            runCatching { process.destroy() }
          }
        } else {
          val localProcess =
            Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
          try {
            val stdout =
              BufferedReader(InputStreamReader(localProcess.inputStream)).use { it.readText() }
            val stderr =
              BufferedReader(InputStreamReader(localProcess.errorStream)).use { it.readText() }
            localProcess.waitFor(4, TimeUnit.SECONDS)
            val exitCode = runCatching { localProcess.exitValue() }.getOrDefault(-1)
            if (exitCode == 0) {
              stdout.trim().ifBlank { "OK (Shell local)" }
            } else {
              throw IllegalStateException(
                stderr.trim().ifBlank { "Requer Shizuku (código $exitCode)" }
              )
            }
          } finally {
            runCatching { localProcess.destroy() }
          }
        }
      }
    }

  @Throws(Exception::class)
  private fun createShizukuProcess(command: String): Process {
    val method =
      Shizuku::class
        .java
        .getDeclaredMethod(
          "newProcess",
          Array<String>::class.java,
          Array<String>::class.java,
          String::class.java,
        )
    method.isAccessible = true
    val invoked = method.invoke(null, arrayOf("sh", "-c", command), null, null)
    return invoked as Process
  }
}
