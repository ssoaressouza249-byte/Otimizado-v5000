package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.InstalledAppInfo
import com.example.model.OptimizationCategory
import com.example.model.OptimizationFeature
import com.example.model.ShizukuStatus
import com.example.model.TelemetryState
import com.example.ui.theme.CardBlack
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.DimBlue
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.LightGray
import com.example.ui.theme.MutedGray
import com.example.ui.theme.PanelDark
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.OptimizerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen(viewModel: OptimizerViewModel) {
  val shizukuStatus by viewModel.shizukuStatus.collectAsStateWithLifecycle()
  val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
  val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
  val selectedApp by viewModel.selectedApp.collectAsStateWithLifecycle()
  val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
  val activeFeatureIds by viewModel.activeFeatureIds.collectAsStateWithLifecycle()
  val featureFeedback by viewModel.featureFeedback.collectAsStateWithLifecycle()
  val isBoosting by viewModel.isBoosting.collectAsStateWithLifecycle()
  val boostProgress by viewModel.boostProgress.collectAsStateWithLifecycle()
  val boostComplete by viewModel.boostComplete.collectAsStateWithLifecycle()
  val boostLogs by viewModel.boostLogs.collectAsStateWithLifecycle()
  val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

  var showAppPickerSheet by remember { mutableStateOf(false) }

  val categoryFeatures =
    remember(selectedCategory, viewModel.allFeatures) {
      viewModel.allFeatures.filter { it.category == selectedCategory }
    }

  Scaffold(
    containerColor = PureBlack,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    topBar = {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .background(PureBlack)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
      ) {
        TopHeaderRow(
          shizukuStatus = shizukuStatus,
          onShizukuClick = { viewModel.onShizukuBadgeClick() },
        )
        Spacer(modifier = Modifier.height(10.dp))
        TelemetryPanel(telemetry = telemetry)
      }
    },
    bottomBar = {
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .background(PureBlack)
            .navigationBarsPadding()
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = stringResource(id = R.string.footer_credits),
          color = LightGray,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Medium,
          modifier = Modifier.testTag("footer_credits_text"),
        )
      }
    },
  ) { innerPadding ->
    LazyColumn(
      modifier =
        Modifier.fillMaxSize()
          .background(PureBlack)
          .padding(innerPadding),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      if (statusBanner != null) {
        item(key = "status_banner") {
          StatusFeedbackBanner(
            message = statusBanner.orEmpty(),
            onDismiss = { viewModel.dismissBanner() },
          )
        }
      }

      item(key = "turbo_boost_card") {
        TurboBoostHeroCard(
          selectedApp = selectedApp,
          isBoosting = isBoosting,
          boostProgress = boostProgress,
          boostComplete = boostComplete,
          boostLogs = boostLogs,
          onOpenAppPicker = { showAppPickerSheet = true },
          onTurboBoostClick = { viewModel.runTurboBoost() },
          onLaunchGameClick = { viewModel.launchSelectedApp() },
        )
      }

      item(key = "category_tabs") {
        CategoryTabsRow(
          selectedCategory = selectedCategory,
          allFeatures = viewModel.allFeatures,
          activeFeatureIds = activeFeatureIds,
          onSelectCategory = { viewModel.selectCategory(it) },
        )
      }

      items(items = categoryFeatures, key = { it.id }) { feature ->
        val isEnabled = activeFeatureIds.contains(feature.id)
        OptimizationFeatureCard(
          feature = feature,
          isEnabled = isEnabled,
          feedbackMessage = featureFeedback[feature.id],
          onToggle = { checked -> viewModel.toggleFeature(feature, checked) },
        )
      }

      item(key = "bottom_spacer") {
        Spacer(modifier = Modifier.height(8.dp))
      }
    }
  }

  if (showAppPickerSheet) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
      onDismissRequest = { showAppPickerSheet = false },
      sheetState = sheetState,
      containerColor = CardBlack,
      contentColor = PureWhite,
    ) {
      AppPickerSheetContent(
        apps = installedApps,
        selectedPackage = selectedApp.packageName,
        onSelectApp = { app ->
          viewModel.selectApp(app)
          showAppPickerSheet = false
        },
      )
    }
  }
}

@Composable
private fun TopHeaderRow(
  shizukuStatus: ShizukuStatus,
  onShizukuClick: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier =
          Modifier.size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(DimBlue),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.Bolt,
          contentDescription = "Ícone Otimizado V500",
          tint = ElectricBlue,
          modifier = Modifier.size(22.dp),
        )
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(
          text = stringResource(id = R.string.app_name),
          color = PureWhite,
          fontSize = 19.sp,
          fontWeight = FontWeight.ExtraBold,
          fontFamily = FontFamily.Default,
        )
        Text(
          text = "GAMING ENGINE • ZERO LAG",
          color = ElectricBlue,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace,
        )
      }
    }

    val (badgeLabel, dotColor, borderColor) =
      when (shizukuStatus) {
        ShizukuStatus.CONNECTED ->
          Triple(stringResource(R.string.shizuku_connected), ConnectedGreen, ElectricBlue)
        ShizukuStatus.PERMISSION_REQUIRED ->
          Triple(stringResource(R.string.shizuku_permission_needed), WarningAmber, WarningAmber)
        ShizukuStatus.NOT_RUNNING ->
          Triple(stringResource(R.string.shizuku_activate), ElectricBlue, SecondaryBlue)
      }

    Surface(
      onClick = onShizukuClick,
      color = CardBlack,
      shape = RoundedCornerShape(20.dp),
      border = BorderStroke(1.dp, borderColor),
      modifier = Modifier.minimumInteractiveComponentSize().testTag("shizuku_status_badge"),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier = Modifier.size(8.dp).clip(CircleShape).background(dotColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = badgeLabel,
          color = PureWhite,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace,
        )
      }
    }
  }
}

@Composable
private fun TelemetryPanel(telemetry: TelemetryState) {
  Card(
    colors = CardDefaults.cardColors(containerColor = CardBlack),
    border = BorderStroke(1.dp, ElectricBlue),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      TelemetryMetricItem(
        label = "FPS ATUAL",
        value = "${telemetry.currentFps}",
        unit = "FPS",
        modifier = Modifier.weight(1f).testTag("telemetry_fps"),
      )
      VerticalBlueDivider()
      TelemetryMetricItem(
        label = "TAXA DE TELA",
        value = "${telemetry.refreshRateHz.toInt()}",
        unit = "Hz (Máx ${telemetry.maxSupportedHz.toInt()})",
        modifier = Modifier.weight(1.2f).testTag("telemetry_hz"),
      )
      VerticalBlueDivider()
      TelemetryMetricItem(
        label = "RAM LIVRE",
        value = "${telemetry.freeRamMb}",
        unit = "MB",
        modifier = Modifier.weight(1f).testTag("telemetry_ram"),
      )
    }
  }
}

@Composable
private fun VerticalBlueDivider() {
  Box(
    modifier =
      Modifier.width(1.dp)
        .height(28.dp)
        .background(ElectricBlue.copy(alpha = 0.35f))
  )
}

@Composable
private fun TelemetryMetricItem(
  label: String,
  value: String,
  unit: String,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier.padding(horizontal = 6.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Text(
      text = label,
      color = LightGray,
      fontSize = 9.sp,
      fontWeight = FontWeight.SemiBold,
      fontFamily = FontFamily.Monospace,
      maxLines = 1,
    )
    Spacer(modifier = Modifier.height(2.dp))
    Row(verticalAlignment = Alignment.Bottom) {
      Text(
        text = value,
        color = PureWhite,
        fontSize = 16.sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = FontFamily.Monospace,
      )
      Spacer(modifier = Modifier.width(3.dp))
      Text(
        text = unit,
        color = ElectricBlue,
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(bottom = 2.dp),
      )
    }
  }
}

@Composable
private fun StatusFeedbackBanner(
  message: String,
  onDismiss: () -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = PanelDark),
    border = BorderStroke(1.dp, SecondaryBlue),
    shape = RoundedCornerShape(10.dp),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(
        text = message,
        color = PureWhite,
        fontSize = 12.sp,
        fontFamily = FontFamily.Default,
        modifier = Modifier.weight(1f),
      )
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Icon(
          imageVector = Icons.Outlined.Close,
          contentDescription = "Fechar aviso",
          tint = LightGray,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}

@Composable
private fun TurboBoostHeroCard(
  selectedApp: InstalledAppInfo,
  isBoosting: Boolean,
  boostProgress: Float,
  boostComplete: Boolean,
  boostLogs: List<String>,
  onOpenAppPicker: () -> Unit,
  onTurboBoostClick: () -> Unit,
  onLaunchGameClick: () -> Unit,
) {
  val animatedProgress by
    animateFloatAsState(
      targetValue = boostProgress,
      animationSpec = spring(),
      label = "boost_progress_anim",
    )

  Card(
    colors = CardDefaults.cardColors(containerColor = CardBlack),
    border = BorderStroke(1.dp, ElectricBlue),
    shape = RoundedCornerShape(14.dp),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.RocketLaunch,
            contentDescription = "Turbo Boost",
            tint = ElectricBlue,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "TURBO BOOST • JOGO ALVO",
            color = ElectricBlue,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
          )
        }
        if (selectedApp.isFreeFire) {
          Surface(
            color = DimBlue,
            shape = RoundedCornerShape(6.dp),
            border = BorderStroke(1.dp, ElectricBlue),
          ) {
            Text(
              text = "FREE FIRE",
              color = PureWhite,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Target App Selector Row
      Surface(
        onClick = onOpenAppPicker,
        color = PureBlack,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, SecondaryBlue),
        modifier =
          Modifier.fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("app_selector_button"),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = selectedApp.label,
              color = PureWhite,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = selectedApp.packageName,
              color = LightGray,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "TROCAR",
              color = ElectricBlue,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
            )
            Icon(
              imageVector = Icons.Filled.KeyboardArrowDown,
              contentDescription = "Selecionar app",
              tint = ElectricBlue,
              modifier = Modifier.size(20.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Giant Blue Button: OTIMIZAR FF AGORA / OTIMIZAR APP SELECIONADO
      val primaryButtonText =
        if (selectedApp.isFreeFire) stringResource(R.string.btn_optimize_ff)
        else stringResource(R.string.btn_optimize_app)

      Button(
        onClick = onTurboBoostClick,
        enabled = !isBoosting,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = ElectricBlue,
            contentColor = PureWhite,
            disabledContainerColor = SecondaryBlue.copy(alpha = 0.6f),
            disabledContentColor = PureWhite,
          ),
        shape = RoundedCornerShape(12.dp),
        modifier =
          Modifier.fillMaxWidth()
            .height(56.dp)
            .testTag("turbo_boost_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.Bolt,
          contentDescription = null,
          tint = PureWhite,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isBoosting) "OTIMIZANDO..." else primaryButtonText,
          fontSize = 15.sp,
          fontWeight = FontWeight.ExtraBold,
          fontFamily = FontFamily.Default,
          letterSpacing = 0.6.sp,
        )
      }

      AnimatedVisibility(visible = isBoosting || boostLogs.isNotEmpty()) {
        Column(modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
          LinearProgressIndicator(
            progress = { animatedProgress },
            color = ElectricBlue,
            trackColor = DimBlue,
            strokeCap = StrokeCap.Round,
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
          )

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            color = PureBlack,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, SecondaryBlue.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Filled.Terminal,
                  contentDescription = "Log de otimização",
                  tint = ElectricBlue,
                  modifier = Modifier.size(14.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "LOG EM TEMPO REAL",
                  color = ElectricBlue,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.Monospace,
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              boostLogs.forEach { logLine ->
                Text(
                  text = logLine,
                  color = if (logLine.startsWith("[CONCLUÍDO]")) ConnectedGreen else LightGray,
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace,
                  lineHeight = 14.sp,
                )
              }
            }
          }
        }
      }

      AnimatedVisibility(visible = boostComplete && !isBoosting) {
        Column(modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
          Button(
            onClick = onLaunchGameClick,
            colors =
              ButtonDefaults.buttonColors(
                containerColor = ElectricBlue,
                contentColor = PureWhite,
              ),
            shape = RoundedCornerShape(12.dp),
            modifier =
              Modifier.fillMaxWidth()
                .height(50.dp)
                .testTag("launch_optimized_game_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.PlayArrow,
              contentDescription = null,
              tint = PureWhite,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = stringResource(R.string.btn_launch_optimized),
              fontSize = 14.sp,
              fontWeight = FontWeight.ExtraBold,
              fontFamily = FontFamily.Default,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun CategoryTabsRow(
  selectedCategory: OptimizationCategory,
  allFeatures: List<OptimizationFeature>,
  activeFeatureIds: Set<Int>,
  onSelectCategory: (OptimizationCategory) -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    OptimizationCategory.entries.forEach { category ->
      val isSelected = selectedCategory == category
      val totalInCat = allFeatures.count { it.category == category }
      val activeInCat = allFeatures.count { it.category == category && activeFeatureIds.contains(it.id) }
      val icon =
        when (category) {
          OptimizationCategory.FPS_AND_HZ -> Icons.Filled.Speed
          OptimizationCategory.TOUCH_DELAY -> Icons.Filled.TouchApp
          OptimizationCategory.LIGHT_SYSTEM -> Icons.Filled.Memory
        }

      Surface(
        onClick = { onSelectCategory(category) },
        color = if (isSelected) ElectricBlue else CardBlack,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (isSelected) ElectricBlue else SecondaryBlue),
        modifier =
          Modifier.weight(1f)
            .minimumInteractiveComponentSize()
            .testTag("tab_${category.name.lowercase()}"),
      ) {
        Column(
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 10.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Icon(
            imageVector = icon,
            contentDescription = category.tabTitle,
            tint = PureWhite,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = category.tabTitle,
            color = PureWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = "$activeInCat/$totalInCat",
            color = if (isSelected) PureWhite.copy(alpha = 0.9f) else LightGray,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
          )
        }
      }
    }
  }
}

@Composable
private fun OptimizationFeatureCard(
  feature: OptimizationFeature,
  isEnabled: Boolean,
  feedbackMessage: String?,
  onToggle: (Boolean) -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = CardBlack),
    border =
      BorderStroke(
        width = if (isEnabled) 1.5.dp else 1.dp,
        color = if (isEnabled) ElectricBlue else SecondaryBlue.copy(alpha = 0.75f),
      ),
    shape = RoundedCornerShape(12.dp),
    modifier =
      Modifier.fillMaxWidth()
        .clickable { onToggle(!isEnabled) }
        .testTag("feature_card_${feature.id}"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = if (isEnabled) ElectricBlue else DimBlue,
            shape = RoundedCornerShape(5.dp),
          ) {
            Text(
              text = "#${feature.id.toString().padStart(2, '0')}",
              color = PureWhite,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = feature.title,
            color = PureWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = feature.description,
          color = LightGray,
          fontSize = 12.sp,
          lineHeight = 16.sp,
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.Tune,
            contentDescription = null,
            tint = ElectricBlue,
            modifier = Modifier.size(12.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = feature.commandPreview,
            color = ElectricBlue,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        if (!feedbackMessage.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(4.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.CheckCircle,
              contentDescription = null,
              tint = ConnectedGreen,
              modifier = Modifier.size(12.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = feedbackMessage,
              color = ConnectedGreen,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(10.dp))

      Switch(
        checked = isEnabled,
        onCheckedChange = onToggle,
        colors =
          SwitchDefaults.colors(
            checkedThumbColor = PureWhite,
            checkedTrackColor = ElectricBlue,
            checkedBorderColor = ElectricBlue,
            uncheckedThumbColor = LightGray,
            uncheckedTrackColor = PureBlack,
            uncheckedBorderColor = SecondaryBlue,
          ),
        modifier = Modifier.testTag("feature_switch_${feature.id}"),
      )
    }
  }
}

@Composable
private fun AppPickerSheetContent(
  apps: List<InstalledAppInfo>,
  selectedPackage: String,
  onSelectApp: (InstalledAppInfo) -> Unit,
) {
  var searchQuery by remember { mutableStateOf("") }
  val filteredApps =
    remember(apps, searchQuery) {
      if (searchQuery.isBlank()) apps
      else {
        val q = searchQuery.trim().lowercase()
        apps.filter {
          it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
        }
      }
    }

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    Text(
      text = "SELECIONAR JOGO OU APP",
      color = PureWhite,
      fontSize = 16.sp,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = FontFamily.Default,
    )
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = "Free Fire e Free Fire MAX têm prioridade automática quando instalados.",
      color = LightGray,
      fontSize = 12.sp,
    )

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("Buscar app ou pacote...", color = MutedGray, fontSize = 13.sp) },
      leadingIcon = {
        Icon(
          imageVector = Icons.Filled.Search,
          contentDescription = "Buscar",
          tint = ElectricBlue,
        )
      },
      singleLine = true,
      colors =
        OutlinedTextFieldDefaults.colors(
          focusedBorderColor = ElectricBlue,
          unfocusedBorderColor = SecondaryBlue,
          focusedTextColor = PureWhite,
          unfocusedTextColor = PureWhite,
          cursorColor = ElectricBlue,
          focusedContainerColor = PureBlack,
          unfocusedContainerColor = PureBlack,
        ),
      shape = RoundedCornerShape(10.dp),
      modifier = Modifier.fillMaxWidth().testTag("app_search_input"),
    )

    Spacer(modifier = Modifier.height(10.dp))

    LazyColumn(
      modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      items(items = filteredApps, key = { it.packageName }) { app ->
        val isCurrent = app.packageName == selectedPackage
        Surface(
          onClick = { onSelectApp(app) },
          color = if (isCurrent) DimBlue else PureBlack,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, if (isCurrent) ElectricBlue else SecondaryBlue.copy(alpha = 0.6f)),
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = app.label,
                color = PureWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = app.packageName,
                color = LightGray,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            if (app.isFreeFire) {
              Spacer(modifier = Modifier.width(8.dp))
              Surface(
                color = ElectricBlue,
                shape = RoundedCornerShape(6.dp),
              ) {
                Text(
                  text = "PRIORIDADE",
                  color = PureWhite,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.Monospace,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                )
              }
            }
          }
        }
      }
    }

    HorizontalDivider(
      color = PureBlack,
      modifier = Modifier.padding(vertical = 8.dp),
    )
  }
}
