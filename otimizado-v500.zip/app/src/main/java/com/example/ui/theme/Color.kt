package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val CardBlack = Color(0xFF05080F)
val PanelDark = Color(0xFF080E1A)
val ElectricBlue = Color(0xFF2979FF)
val SecondaryBlue = Color(0xFF1E88E5)
val DimBlue = Color(0xFF102A54)
val PureWhite = Color(0xFFFFFFFF)
val LightGray = Color(0xFFB0BEC5)
val MutedGray = Color(0xFF78909C)
val ConnectedGreen = Color(0xFF00E676)
val WarningAmber = Color(0xFFFFAB00)
val SecurityAlertRed = Color(0xFFB71C1C)
