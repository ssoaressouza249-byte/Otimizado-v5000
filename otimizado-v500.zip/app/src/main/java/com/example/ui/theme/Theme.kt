package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val OtimizadoColorScheme =
  darkColorScheme(
    primary = ElectricBlue,
    onPrimary = PureWhite,
    primaryContainer = DimBlue,
    onPrimaryContainer = PureWhite,
    secondary = SecondaryBlue,
    onSecondary = PureWhite,
    background = PureBlack,
    onBackground = PureWhite,
    surface = CardBlack,
    onSurface = PureWhite,
    surfaceVariant = PanelDark,
    onSurfaceVariant = LightGray,
    outline = ElectricBlue,
    outlineVariant = SecondaryBlue,
    error = SecurityAlertRed,
    onError = PureWhite,
  )

@Composable
fun OtimizadoV500Theme(content: @Composable () -> Unit) {
  MaterialTheme(colorScheme = OtimizadoColorScheme, typography = Typography, content = content)
}
