package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.InstalledAppInfo
import com.example.model.OptimizationCategory
import com.example.model.OptimizationFeature
import com.example.model.ShizukuStatus
import com.example.model.TelemetryState
import com.example.system.DeviceTelemetryMonitor
import com.example.system.OptimizationCatalog
import com.example.system.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OptimizerViewModel(application: Application) : AndroidViewModel(application) {

  private val appContext = application.applicationContext
  private val prefs =
    runCatching { appContext.getSharedPreferences("otimizado_v500_prefs", Context.MODE_PRIVATE) }
      .getOrNull()

  val shizukuManager = ShizukuManager()
  val telemetryMonitor = DeviceTelemetryMonitor(appContext)

  val shizukuStatus: StateFlow<ShizukuStatus> = shizukuManager.status
  val telemetry: StateFlow<TelemetryState> = telemetryMonitor.telemetry

  val allFeatures: List<OptimizationFeature> = OptimizationCatalog.getAllFeatures()

  private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
  val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

  private val _selectedApp =
    MutableStateFlow(
      InstalledAppInfo(
        packageName = DeviceTelemetryMonitor.FREE_FIRE_PKG,
        label = "Free Fire",
        isFreeFire = true,
      )
    )
  val selectedApp: StateFlow<InstalledAppInfo> = _selectedApp.asStateFlow()

  private val _selectedCategory = MutableStateFlow(OptimizationCategory.FPS_AND_HZ)
  val selectedCategory: StateFlow<OptimizationCategory> = _selectedCategory.asStateFlow()

  private val _activeFeatureIds = MutableStateFlow<Set<Int>>(loadSavedFeatureIds())
  val activeFeatureIds: StateFlow<Set<Int>> = _activeFeatureIds.asStateFlow()

  private val _featureFeedback = MutableStateFlow<Map<Int, String>>(emptyMap())
  val featureFeedback: StateFlow<Map<Int, String>> = _featureFeedback.asStateFlow()

  private val _isBoosting = MutableStateFlow(false)
  val isBoosting: StateFlow<Boolean> = _isBoosting.asStateFlow()

  private val _boostProgress = MutableStateFlow(0f)
  val boostProgress: StateFlow<Float> = _boostProgress.asStateFlow()

  private val _boostComplete = MutableStateFlow(false)
  val boostComplete: StateFlow<Boolean> = _boostComplete.asStateFlow()

  private val _boostLogs = MutableStateFlow<List<String>>(emptyList())
  val boostLogs: StateFlow<List<String>> = _boostLogs.asStateFlow()

  private val _statusBanner = MutableStateFlow<String?>(null)
  val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

  private val _requestWindowRefreshBoost = MutableStateFlow(false)
  val requestWindowRefreshBoost: StateFlow<Boolean> = _requestWindowRefreshBoost.asStateFlow()

  private val _requestSustainedPerformance = MutableStateFlow(false)
  val requestSustainedPerformance: StateFlow<Boolean> = _requestSustainedPerformance.asStateFlow()

  init {
    shizukuManager.registerListeners()
    loadApps()
    if (_activeFeatureIds.value.contains(1)) _requestWindowRefreshBoost.value = true
    if (_activeFeatureIds.value.contains(6)) _requestSustainedPerformance.value = true
  }

  private fun loadSavedFeatureIds(): Set<Int> {
    return runCatching {
        prefs?.getStringSet("active_features", emptySet())?.mapNotNull { it.toIntOrNull() }?.toSet()
          ?: emptySet()
      }
      .getOrDefault(emptySet())
  }

  private fun saveFeatureIds(ids: Set<Int>) {
    runCatching {
      prefs?.edit()?.putStringSet("active_features", ids.map { it.toString() }.toSet())?.apply()
    }
  }

  fun startMonitoring() {
    shizukuManager.refreshStatus()
    telemetryMonitor.start()
  }

  fun stopMonitoring() {
    telemetryMonitor.stop()
  }

  fun loadApps() {
    viewModelScope.launch {
      val apps = withContext(Dispatchers.IO) { telemetryMonitor.loadInstalledApps() }
      _installedApps.value = apps
      val preferred =
        apps.firstOrNull { it.packageName == DeviceTelemetryMonitor.FREE_FIRE_PKG }
          ?: apps.firstOrNull { it.packageName == DeviceTelemetryMonitor.FREE_FIRE_MAX_PKG }
          ?: apps.firstOrNull()
      if (preferred != null) {
        _selectedApp.value = preferred
      }
    }
  }

  fun selectApp(app: InstalledAppInfo) {
    _selectedApp.value = app
    _boostComplete.value = false
    _statusBanner.value = "Alvo selecionado: ${app.label}"
  }

  fun selectCategory(category: OptimizationCategory) {
    _selectedCategory.value = category
  }

  fun onShizukuBadgeClick() {
    val msg = shizukuManager.requestOrOpenShizuku(appContext)
    _statusBanner.value = msg
  }

  fun dismissBanner() {
    _statusBanner.value = null
  }

  fun toggleFeature(feature: OptimizationFeature, enabled: Boolean) {
    val updated =
      if (enabled) _activeFeatureIds.value + feature.id else _activeFeatureIds.value - feature.id
    _activeFeatureIds.value = updated
    saveFeatureIds(updated)

    if (feature.id == 1) _requestWindowRefreshBoost.value = enabled
    if (feature.id == 6) _requestSustainedPerformance.value = enabled

    viewModelScope.launch {
      val targetPkg = _selectedApp.value.packageName
      val maxHz = telemetry.value.maxSupportedHz.coerceAtLeast(60f)
      val commands =
        if (enabled) feature.enableCommands(appContext, targetPkg, maxHz)
        else feature.disableCommands(appContext, targetPkg)

      val shizukuActive = shizukuManager.refreshStatus() == ShizukuStatus.CONNECTED
      val feedbackMsg: String

      if (shizukuActive && commands.isNotEmpty()) {
        val results = commands.map { cmd -> cmd to shizukuManager.executeCommand(cmd) }
        val allSuccess = results.all { it.second.isSuccess }
        val firstFailure = results.firstOrNull { it.second.isFailure }?.second?.exceptionOrNull()?.message
        feedbackMsg =
          if (allSuccess) {
            if (enabled) "Aplicado via Shizuku (${commands.size} cmd)"
            else "Restaurado via Shizuku"
          } else {
            val nativeNote = feature.nativeFallback(appContext, targetPkg, enabled)
            "Shizuku parcial (${firstFailure ?: "aviso"}): $nativeNote"
          }
      } else {
        feedbackMsg = feature.nativeFallback(appContext, targetPkg, enabled)
      }

      _featureFeedback.value = _featureFeedback.value + (feature.id to feedbackMsg)
      telemetryMonitor.refreshOnce()
    }
  }

  fun runTurboBoost() {
    if (_isBoosting.value) return
    val target = _selectedApp.value
    val maxHz = telemetry.value.maxSupportedHz.coerceAtLeast(120f)
    val peakHz = maxOf(144f, telemetry.value.maxSupportedHz)
    val minHz = if (telemetry.value.maxSupportedHz >= 120f) 120f else telemetry.value.maxSupportedHz

    viewModelScope.launch {
      _isBoosting.value = true
      _boostComplete.value = false
      _boostProgress.value = 0.05f
      _boostLogs.value =
        listOf("[V500] Iniciando Turbo Boost para ${target.label} (${target.packageName})...")

      _requestWindowRefreshBoost.value = true
      _requestSustainedPerformance.value = true

      val shizukuReady = shizukuManager.refreshStatus() == ShizukuStatus.CONNECTED
      val modeTag = if (shizukuReady) "SHIZUKU" else "NATIVO"

      // Passo 1: Limpeza profunda de RAM
      appendLog("[$modeTag] Executando limpeza profunda de RAM (am kill-all)...")
      val nativeKilled = withContext(Dispatchers.IO) { telemetryMonitor.clearBackgroundProcessesNative() }
      if (shizukuReady) {
        val res = shizukuManager.executeCommand("am kill-all")
        appendLog(
          if (res.isSuccess) "  -> RAM limpa via Shizuku + $nativeKilled processos locais."
          else "  -> Limpeza nativa aplicada ($nativeKilled apps)."
        )
      } else {
        appendLog("  -> Limpeza nativa executada ($nativeKilled apps liberados).")
      }
      _boostProgress.value = 0.22f
      delay(180)

      // Passo 2: Limpar caches temporários
      appendLog("[$modeTag] Limpando caches temporários (pm trim-caches 512M)...")
      if (shizukuReady) {
        val res = shizukuManager.executeCommand("pm trim-caches 512M")
        appendLog(
          if (res.isSuccess) "  -> Caches globais reduzidos em 512M."
          else "  -> Cache local liberado (pm trim-caches requer Shizuku)."
        )
      } else {
        runCatching { appContext.cacheDir?.deleteRecursively() }
        appendLog("  -> Cache interno limpo (ative Shizuku para trim global).")
      }
      _boostProgress.value = 0.42f
      delay(180)

      // Passo 3: Game Manager Performance
      appendLog("[$modeTag] Ativando Game Performance (cmd game mode performance)...")
      if (shizukuReady) {
        val res = shizukuManager.executeCommand("cmd game mode performance ${target.packageName}")
        appendLog(
          if (res.isSuccess) "  -> Game Mode Performance ativo em ${target.packageName}."
          else "  -> Aviso Game Mode: ${res.exceptionOrNull()?.message ?: "indisponível"}"
        )
      } else {
        appendLog("  -> Prioridade de janela e thread de renderização aplicada.")
      }
      _boostProgress.value = 0.64f
      delay(180)

      // Passo 4: Destravar Hz máximo
      appendLog("[$modeTag] Forçando taxa de atualização máxima (${maxHz.toInt()}Hz)...")
      if (shizukuReady) {
        shizukuManager.executeCommand("settings put system peak_refresh_rate $peakHz")
        shizukuManager.executeCommand("settings put system min_refresh_rate $minHz")
        appendLog("  -> Refresh rate destravado (peak=$peakHz / min=$minHz).")
      } else {
        appendLog("  -> Modo de exibição máximo solicitado na janela (${maxHz.toInt()}Hz).")
      }
      _boostProgress.value = 0.84f
      delay(180)

      // Passo 5: Desativar animações pesadas
      appendLog("[$modeTag] Zerando animações (window/transition/animator = 0)...")
      if (shizukuReady) {
        shizukuManager.executeCommand("settings put global window_animation_scale 0")
        shizukuManager.executeCommand("settings put global transition_animation_scale 0")
        shizukuManager.executeCommand("settings put global animator_duration_scale 0")
        appendLog("  -> Escalas de animação zeradas via Shizuku.")
      } else {
        appendLog("  -> Perfil zero-animação preparado (ative Shizuku para escala global).")
      }

      _boostProgress.value = 1f
      telemetryMonitor.refreshOnce()
      val freeRamAfter = telemetry.value.freeRamMb
      appendLog("[CONCLUÍDO] ${target.label} pronto! RAM Livre atual: ${freeRamAfter} MB.")
      _isBoosting.value = false
      _boostComplete.value = true
    }
  }

  private fun appendLog(line: String) {
    _boostLogs.value = (_boostLogs.value + line).takeLast(12)
  }

  fun launchSelectedApp() {
    val pkg = _selectedApp.value.packageName
    val launched =
      runCatching {
          val launchIntent = appContext.packageManager.getLaunchIntentForPackage(pkg)
          if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(launchIntent)
            true
          } else {
            false
          }
        }
        .getOrDefault(false)

    if (!launched) {
      _statusBanner.value = "Pacote $pkg não está instalado neste dispositivo."
    }
  }

  override fun onCleared() {
    super.onCleared()
    telemetryMonitor.stop()
    shizukuManager.unregisterListeners()
  }
}
