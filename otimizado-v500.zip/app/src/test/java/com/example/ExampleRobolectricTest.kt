package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.OptimizationCategory
import com.example.security.SecurityGuard
import com.example.system.OptimizationCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class ExampleRobolectricTest {

  @Test
  fun `app name and package match security guard`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Otimizado V500", appName)
    assertEquals("com.raylan.otimizadov500", context.packageName)
    assertTrue(SecurityGuard.isAppAuthentic(context))
  }

  @Test
  fun `catalog contains exact 25 distinct functions across 3 tabs`() {
    val features = OptimizationCatalog.getAllFeatures()
    assertEquals(25, features.size)
    assertEquals(25, features.map { it.id }.toSet().size)
    assertEquals(9, features.count { it.category == OptimizationCategory.FPS_AND_HZ })
    assertEquals(8, features.count { it.category == OptimizationCategory.TOUCH_DELAY })
    assertEquals(8, features.count { it.category == OptimizationCategory.LIGHT_SYSTEM })
  }
}
